s = ""
while s != "x":
    print("Enter a word or phrase: ")
    s = input()
    max = len(s) - 1
    matched = True
    for i in range(0, max):
        Letter1 = s[i]
        Letter2 = s[max-i]
        if Letter1 != Letter2:
            matched = False
    if matched == True:
        print("Palindrome")
    else:
        print("Not a palindrome")