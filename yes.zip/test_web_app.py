import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import chess

from app import (
    DatabaseConnection,
    connect_database,
    create_app,
    database,
    is_brilliant_sacrifice,
    load_room,
    rate_completed_game,
)


class WebAppTests(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.database = Path(self.temp_dir.name) / "test.sqlite3"
        self.app = create_app(self.database, secret_key="test-secret-key")
        self.app.config.update(TESTING=True)
        self.client = self.app.test_client()
        self.random_side_patcher = patch("app.secrets.randbelow", return_value=0)
        self.random_side_patcher.start()

    def tearDown(self):
        self.random_side_patcher.stop()
        self.temp_dir.cleanup()

    def post(self, client, path, body):
        return client.post(path, data=json.dumps(body), content_type="application/json")

    def register(self, client, username):
        response = self.post(client, "/api/register", {
            "username": username,
            "password": "correct horse battery staple",
        })
        self.assertEqual(response.status_code, 201, response.get_json())
        return response.get_json()["user"]

    def test_lobby_and_browser_assets_are_served(self):
        for path in ("/", "/play", "/lobby.js", "/app.js"):
            response = self.client.get(path)
            self.assertEqual(response.status_code, 200)
            response.close()
        self.assertEqual(self.client.get("/health").get_json(), {"status": "ok"})

    def test_global_chat_requires_an_account_to_post_and_supports_friend_invites(self):
        self.assertEqual(self.client.get("/api/global-chat").get_json()["messages"], [])
        self.assertEqual(
            self.post(self.client, "/api/global-chat", {"message": "Hello"}).status_code,
            401,
        )
        self.register(self.client, "Alice")
        bob_client = self.app.test_client()
        bob = self.register(bob_client, "Bobby")

        sent = self.post(self.client, "/api/global-chat", {"message": "  Game anyone?  "})
        self.assertEqual(sent.status_code, 201, sent.get_json())
        self.assertEqual(
            self.post(self.client, "/api/global-chat", {"message": "   "}).status_code,
            400,
        )
        too_long = self.post(
            self.client, "/api/global-chat", {"message": "x" * 281}
        )
        self.assertEqual(too_long.status_code, 400)
        bob_messages = bob_client.get("/api/global-chat").get_json()["messages"]
        self.assertEqual(bob_messages[0]["message"], "Game anyone?")
        self.assertFalse(bob_messages[0]["own"])
        self.assertFalse(bob_messages[0]["isFriend"])
        self.assertIsNone(bob_messages[0]["sentRequestId"])

        self.post(bob_client, "/api/global-chat", {"message": "Ready to play?"})
        request = self.post(
            bob_client, "/api/friends/requests", {"username": "Alice"}
        )
        self.assertEqual(request.status_code, 201, request.get_json())
        bob_message = self.client.get("/api/global-chat").get_json()["messages"][-1]
        self.assertEqual(bob_message["username"], "Bobby")
        self.assertIsNotNone(bob_message["receivedRequestId"])
        self.assertEqual(
            self.post(
                self.client,
                f"/api/friends/requests/{bob_message['receivedRequestId']}",
                {"accept": True},
            ).status_code,
            200,
        )
        bob_message = self.client.get("/api/global-chat").get_json()["messages"][-1]
        self.assertTrue(bob_message["isFriend"])
        invitation = self.post(self.client, "/api/invitations", {
            "friendId": bob["id"],
            "timeControl": "blitz_3_0",
        })
        self.assertEqual(invitation.status_code, 201, invitation.get_json())
        self.assertTrue(invitation.get_json()["roomCode"])

    def test_room_chat_supports_messages_typing_and_player_authorization(self):
        created = self.post(self.client, "/api/rooms", {}).get_json()
        code = created["roomCode"]
        opponent = self.app.test_client()
        joined = self.post(opponent, f"/api/rooms/{code}/join", {})
        self.assertEqual(joined.status_code, 200, joined.get_json())

        sent = self.post(self.client, f"/api/rooms/{code}/chat", {
            "message": "  Good luck!  ",
        })
        self.assertEqual(sent.status_code, 201, sent.get_json())
        self.assertEqual(
            self.post(
                self.client, f"/api/rooms/{code}/chat/typing", {"isTyping": True}
            ).status_code,
            200,
        )
        opponent_chat = opponent.get(f"/api/rooms/{code}/chat").get_json()
        self.assertEqual(opponent_chat["messages"][0]["message"], "Good luck!")
        self.assertEqual(opponent_chat["messages"][0]["side"], "w")
        self.assertEqual(opponent_chat["playerSide"], "b")
        self.assertEqual(opponent_chat["typing"], {"w": True})

        self.post(
            self.client, f"/api/rooms/{code}/chat/typing", {"isTyping": False}
        )
        self.assertEqual(
            opponent.get(f"/api/rooms/{code}/chat").get_json()["typing"], {}
        )
        self.assertEqual(
            self.post(opponent, f"/api/rooms/{code}/chat", {
                "message": "x" * 281,
            }).status_code,
            400,
        )
        outsider = self.app.test_client()
        self.assertEqual(outsider.get(f"/api/rooms/{code}/chat").status_code, 403)

    def test_secure_cookie_setting_is_enabled_in_production(self):
        self.assertFalse(self.app.config["SESSION_COOKIE_SECURE"])
        production_env = {
            "CHESS_ENV": "production",
            "CHESS_DB_ENGINE": "postgres",
            "DB_HOST": "database.example",
            "DB_PORT": "5432",
            "DB_NAME": "chess",
            "DB_USERNAME": "chess",
            "DB_PASSWORD": "database-secret",
        }
        with patch.dict("os.environ", production_env), patch("app.initialize_database"):
            production_app = create_app(secret_key="test-production-secret")
        self.assertTrue(production_app.config["SESSION_COOKIE_SECURE"])
        self.assertEqual(production_app.config["DATABASE_BACKEND"], "postgres")

    def test_postgres_adapter_translates_placeholders_and_case_insensitive_match(self):
        class FakeConnection:
            def execute(self, query, parameters):
                self.query = query
                self.parameters = parameters

        connection = FakeConnection()
        adapter = DatabaseConnection(connection, "postgres")
        adapter.execute(
            "SELECT id FROM users WHERE username = ? COLLATE NOCASE",
            ("Player",),
        )
        self.assertEqual(
            connection.query,
            "SELECT id FROM users WHERE LOWER(username) = LOWER(%s)",
        )
        self.assertEqual(connection.parameters, ("Player",))

    def test_mysql_adapter_translates_ignored_insert(self):
        class FakeCursor:
            def execute(self, query, parameters):
                self.query = query
                self.parameters = parameters

        class FakeConnection:
            def __init__(self):
                self.cursor_value = FakeCursor()

            def cursor(self):
                return self.cursor_value

        connection = FakeConnection()
        adapter = DatabaseConnection(connection, "mysql")
        adapter.execute(
            "INSERT OR IGNORE INTO friendships(user_one, user_two) VALUES (?, ?)",
            (1, 2),
        )
        self.assertEqual(
            connection.cursor_value.query,
            "INSERT IGNORE INTO friendships(user_one, user_two) VALUES (%s, %s)",
        )
        self.assertEqual(connection.cursor_value.parameters, (1, 2))

    def test_postgres_connection_verifies_server_when_ca_file_is_configured(self):
        import psycopg

        config = {
            "DB_HOST": "psql.region.example",
            "DB_PORT": "12345",
            "DB_NAME": "chess",
            "DB_USERNAME": "chess-user",
            "DB_PASSWORD": "database-password",
            "DB_SSL_CA": "/etc/ssl/private/wasmer-db-ca.pem",
        }
        with patch.object(psycopg, "connect") as connect:
            connect_database("postgres", config)
        self.assertEqual(connect.call_args.kwargs["sslmode"], "verify-full")
        self.assertEqual(
            connect.call_args.kwargs["sslrootcert"], config["DB_SSL_CA"]
        )

    def test_postgres_connection_uses_wasmer_compatible_tls_without_ca(self):
        import psycopg

        config = {
            "DB_HOST": "psql.region.example",
            "DB_PORT": "12345",
            "DB_NAME": "chess",
            "DB_USERNAME": "chess-user",
            "DB_PASSWORD": "database-password",
        }
        with patch.object(psycopg, "connect") as connect:
            connect_database("postgres", config)
        self.assertEqual(connect.call_args.kwargs["sslmode"], "require")
        self.assertNotIn("sslrootcert", connect.call_args.kwargs)

    def test_guest_room_allows_two_guests_to_play_and_rejects_illegal_moves(self):
        created = self.post(self.client, "/api/rooms", {}).get_json()
        code = created["roomCode"]
        self.assertEqual(len(code), 8)
        self.assertEqual(self.client.post(f"/api/rooms/{code}/join", json={}).status_code, 200)

        opponent = self.app.test_client()
        joined = opponent.post(f"/api/rooms/{code}/join", json={})
        self.assertEqual(joined.status_code, 200)
        self.assertEqual(joined.get_json()["playerSide"], "b")
        self.assertEqual(joined.get_json()["status"], "active")

        wrong_turn = opponent.post(
            f"/api/rooms/{code}/move", json={"from": "e7", "to": "e5"}
        )
        self.assertEqual(wrong_turn.status_code, 403)
        illegal = self.client.post(
            f"/api/rooms/{code}/move", json={"from": "e2", "to": "e5"}
        )
        self.assertEqual(illegal.status_code, 400)

        played = self.client.post(
            f"/api/rooms/{code}/move", json={"from": "e2", "to": "e4"}
        )
        self.assertEqual(played.status_code, 200, played.get_json())
        self.assertEqual(played.get_json()["turn"], "b")
        self.assertEqual(played.get_json()["history"][0]["san"], "e4")
        self.assertIn("4P3", played.get_json()["history"][0]["fen"])
        self.assertIsNone(played.get_json()["history"][0]["grade"])
        self.assertEqual(played.get_json()["board"][4][4], "wp")
        self.assertEqual(opponent.get(f"/api/rooms/{code}").get_json()["history"][0]["san"], "e4")
        analysis = self.post(self.client, f"/api/rooms/{code}/analysis", {
            "ply": 1,
            "centipawnLoss": 5,
            "evaluation": 32,
            "bestMove": "d2d4",
        })
        self.assertEqual(analysis.status_code, 200, analysis.get_json())
        self.assertEqual(analysis.get_json()["history"][0]["grade"], "Best")
        self.assertEqual(analysis.get_json()["history"][0]["bestMoveSan"], "d4")
        self.assertEqual(analysis.get_json()["evaluation"], 0.32)

    def test_completed_game_review_is_available_to_both_players_only(self):
        created = self.post(self.client, "/api/rooms", {}).get_json()
        code = created["roomCode"]
        opponent = self.app.test_client()
        self.assertEqual(
            opponent.post(f"/api/rooms/{code}/join", json={}).status_code, 200
        )
        self.assertEqual(
            self.post(self.client, f"/api/rooms/{code}/move", {
                "from": "e2",
                "to": "e4",
            }).status_code,
            200,
        )
        self.assertEqual(
            self.post(
                self.client,
                f"/api/rooms/{code}/review/1/alternatives",
                {"moves": ["d2d4"]},
            ).status_code,
            409,
        )
        self.assertEqual(
            self.post(opponent, f"/api/rooms/{code}/forfeit", {}).status_code,
            200,
        )

        for player in (self.client, opponent):
            review = player.get(f"/api/rooms/{code}")
            self.assertEqual(review.status_code, 200, review.get_json())
            self.assertEqual(review.get_json()["status"], "completed")
            self.assertEqual(review.get_json()["history"][0]["san"], "e4")
            self.assertIn("4P3", review.get_json()["history"][0]["fen"])
        unauthorized = self.app.test_client().get(f"/api/rooms/{code}")
        self.assertEqual(unauthorized.status_code, 403)
        alternatives = self.post(
            self.client,
            f"/api/rooms/{code}/review/1/alternatives",
            {"moves": ["d2d4", "c2c4"]},
        )
        self.assertEqual(alternatives.status_code, 200, alternatives.get_json())
        self.assertEqual(
            [move["san"] for move in alternatives.get_json()["alternatives"]],
            ["d4", "c4"],
        )
        self.assertIsNone(
            alternatives.get_json()["alternatives"][0]["attackedTarget"]
        )
        self.assertEqual(
            self.post(
                self.client,
                f"/api/rooms/{code}/review/1/alternatives",
                {"moves": ["e7e5"]},
            ).status_code,
            400,
        )
        self.assertEqual(
            self.post(
                self.app.test_client(),
                f"/api/rooms/{code}/review/1/alternatives",
                {"moves": ["d2d4"]},
            ).status_code,
            403,
        )

    def test_review_alternative_marks_enemy_piece_it_attacks(self):
        created = self.post(self.client, "/api/rooms", {}).get_json()
        code = created["roomCode"]
        opponent = self.app.test_client()
        self.assertEqual(
            opponent.post(f"/api/rooms/{code}/join", json={}).status_code, 200
        )
        for client, start, end in (
            (self.client, "e2", "e4"),
            (opponent, "e7", "e5"),
            (self.client, "g1", "f3"),
        ):
            played = self.post(
                client,
                f"/api/rooms/{code}/move",
                {"from": start, "to": end},
            )
            self.assertEqual(played.status_code, 200, played.get_json())
        self.assertEqual(
            self.post(opponent, f"/api/rooms/{code}/forfeit", {}).status_code,
            200,
        )
        alternatives = self.post(
            self.client,
            f"/api/rooms/{code}/review/3/alternatives",
            {"moves": ["d2d4"]},
        )
        self.assertEqual(alternatives.status_code, 200, alternatives.get_json())
        self.assertEqual(
            alternatives.get_json()["alternatives"][0]["attackedTarget"],
            {"square": "e5", "piece": "pawn", "color": "black"},
        )

    def test_shared_room_randomizes_creator_color(self):
        with patch("app.secrets.randbelow", return_value=1):
            room = self.post(self.client, "/api/rooms", {}).get_json()
        self.assertEqual(room["playerSide"], "b")
        code = room["roomCode"]
        creator = self.client.get(f"/api/rooms/{code}").get_json()
        self.assertEqual(creator["playerSide"], "b")
        self.assertTrue(creator["canCloseWaitingRoom"])

        opponent = self.app.test_client()
        joined = opponent.post(f"/api/rooms/{code}/join", json={})
        self.assertEqual(joined.status_code, 200, joined.get_json())
        self.assertEqual(joined.get_json()["playerSide"], "w")

    def test_near_best_offer_of_a_hanging_piece_is_brilliant(self):
        board = chess.Board("4k3/8/8/8/6p1/8/8/4K1N1 w - - 0 1")
        self.assertTrue(is_brilliant_sacrifice(board, chess.Move.from_uci("g1f3")))

    def test_brilliant_sacrifice_grade_is_saved_to_move_history(self):
        room = self.post(self.client, "/api/rooms", {}).get_json()
        code = room["roomCode"]
        black_client = self.app.test_client()
        self.assertEqual(
            black_client.post(f"/api/rooms/{code}/join", json={}).status_code, 200
        )
        moves = [
            (self.client, "e2", "e4"),
            (black_client, "g7", "g5"),
            (self.client, "d2", "d4"),
            (black_client, "g5", "g4"),
            (self.client, "g1", "f3"),
        ]
        for client, start, end in moves:
            played = client.post(
                f"/api/rooms/{code}/move", json={"from": start, "to": end}
            )
            self.assertEqual(played.status_code, 200, played.get_json())
        analysis = self.post(self.client, f"/api/rooms/{code}/analysis", {
            "ply": 5,
            "centipawnLoss": 0,
            "evaluation": 0,
        })
        self.assertEqual(analysis.status_code, 200, analysis.get_json())
        self.assertEqual(analysis.get_json()["history"][-1]["grade"], "Brilliant")

    def test_missed_win_grade_is_saved_to_move_history(self):
        room = self.post(self.client, "/api/rooms", {}).get_json()
        code = room["roomCode"]
        black_client = self.app.test_client()
        self.assertEqual(
            black_client.post(f"/api/rooms/{code}/join", json={}).status_code, 200
        )
        played = self.client.post(
            f"/api/rooms/{code}/move", json={"from": "e2", "to": "e4"}
        )
        self.assertEqual(played.status_code, 200, played.get_json())
        analysis = self.post(self.client, f"/api/rooms/{code}/analysis", {
            "ply": 1,
            "centipawnLoss": 3000,
            "evaluation": 0,
            "missedWin": True,
        })
        self.assertEqual(analysis.status_code, 200, analysis.get_json())
        self.assertEqual(analysis.get_json()["history"][0]["grade"], "Missed win")

    def test_games_dashboard_includes_both_player_names(self):
        white_client = self.app.test_client()
        black_client = self.app.test_client()
        self.register(white_client, "WhitePlayer")
        self.register(black_client, "BlackPlayer")
        room = self.post(white_client, "/api/rooms", {}).get_json()
        code = room["roomCode"]

        waiting_game = white_client.get("/api/dashboard").get_json()["games"][0]
        self.assertEqual(waiting_game["white_name"], "WhitePlayer")
        self.assertIsNone(waiting_game["black_name"])

        joined = black_client.post(f"/api/rooms/{code}/join", json={})
        self.assertEqual(joined.status_code, 200, joined.get_json())
        for client in (white_client, black_client):
            game = client.get("/api/dashboard").get_json()["games"][0]
            self.assertEqual(game["white_name"], "WhitePlayer")
            self.assertEqual(game["black_name"], "BlackPlayer")

    def test_live_matches_are_public_and_spectating_does_not_join(self):
        white_client = self.app.test_client()
        black_client = self.app.test_client()
        self.register(white_client, "LiveWhite")
        self.register(black_client, "LiveBlack")
        room = self.post(white_client, "/api/rooms", {}).get_json()
        code = room["roomCode"]
        self.assertEqual(
            black_client.post(f"/api/rooms/{code}/join", json={}).status_code, 200
        )
        self.assertEqual(
            white_client.post(f"/api/rooms/{code}/move",
                              json={"from": "e2", "to": "e4"}).status_code,
            200,
        )

        response = self.client.get("/api/live-matches")
        self.assertEqual(response.status_code, 200, response.get_json())
        matches = response.get_json()["matches"]
        self.assertEqual(len(matches), 1)
        self.assertEqual(matches[0]["roomCode"], code)
        self.assertEqual(matches[0]["whiteName"], "LiveWhite")
        self.assertEqual(matches[0]["blackName"], "LiveBlack")
        self.assertEqual(matches[0]["movesPlayed"], 1)

        spectator = self.client.get(f"/api/rooms/{code}/spectate")
        self.assertEqual(spectator.status_code, 200, spectator.get_json())
        self.assertTrue(spectator.get_json()["spectating"])
        self.assertEqual(spectator.get_json()["history"][0]["san"], "e4")
        self.assertEqual(
            self.client.post(
                f"/api/rooms/{code}/move",
                json={"from": "e7", "to": "e5"},
            ).status_code,
            403,
        )
        self.assertEqual(
            black_client.get("/api/dashboard").get_json()["games"][0]["status"],
            "active",
        )

    def test_room_creator_can_close_waiting_room(self):
        creator = self.app.test_client()
        self.register(creator, "RoomCreator")
        room = self.post(creator, "/api/rooms", {}).get_json()

        response = self.post(creator, f"/api/rooms/{room['roomCode']}/close", {})

        self.assertEqual(response.status_code, 200, response.get_json())
        self.assertEqual(response.get_json()["status"], "completed")
        self.assertEqual(creator.get("/api/dashboard").get_json()["games"], [])
        self.assertEqual(
            self.client.post(
                f"/api/rooms/{room['roomCode']}/join", json={}
            ).status_code,
            409,
        )

    def test_closing_active_room_forfeits_and_updates_ratings_once(self):
        white_client = self.app.test_client()
        black_client = self.app.test_client()
        white = self.register(white_client, "ClosingWhite")
        black = self.register(black_client, "ClosingBlack")
        room = self.post(white_client, "/api/rooms", {}).get_json()
        code = room["roomCode"]
        self.assertEqual(black_client.post(f"/api/rooms/{code}/join", json={}).status_code, 200)

        response = self.post(white_client, f"/api/rooms/{code}/close", {})

        self.assertEqual(response.status_code, 200, response.get_json())
        self.assertEqual(response.get_json()["result"], "Black wins by forfeit")
        self.assertEqual(white_client.get("/api/session").get_json()["user"]["rating"], white["rating"] - 16)
        self.assertEqual(black_client.get("/api/session").get_json()["user"]["rating"], black["rating"] + 16)
        repeated = self.post(white_client, f"/api/rooms/{code}/close", {})
        self.assertEqual(repeated.status_code, 409)
        self.assertEqual(white_client.get("/api/session").get_json()["user"]["rating"], white["rating"] - 16)
        self.assertEqual(white_client.get("/api/dashboard").get_json()["games"], [])

    def test_room_close_rejects_non_player(self):
        creator = self.app.test_client()
        self.register(creator, "RoomOwner")
        room = self.post(creator, "/api/rooms", {}).get_json()

        response = self.post(
            self.app.test_client(), f"/api/rooms/{room['roomCode']}/close", {}
        )

        self.assertEqual(response.status_code, 403)

    def test_leaderboard_returns_top_ten_accounts_by_rating(self):
        import sqlite3

        with self.app.app_context():
            connection = sqlite3.connect(self.database)
            connection.executemany(
                "INSERT INTO users(username, password_hash, rating) VALUES (?, ?, ?)",
                [
                    (f"Leader{index:02}", "unused-test-hash", 800 + index * 10)
                    for index in range(12)
                ],
            )
            connection.commit()
            connection.close()

        response = self.client.get("/api/leaderboard")
        self.assertEqual(response.status_code, 200, response.get_json())
        leaders = response.get_json()["leaders"]
        self.assertEqual(len(leaders), 10)
        self.assertEqual(leaders[0]["username"], "Leader11")
        self.assertEqual(leaders[-1]["username"], "Leader02")
        self.assertEqual(
            [leader["rating"] for leader in leaders],
            sorted((leader["rating"] for leader in leaders), reverse=True),
        )
        self.assertNotIn("password_hash", leaders[0])

    def test_public_profile_includes_record_and_recent_match_history(self):
        white_client = self.app.test_client()
        black_client = self.app.test_client()
        white = self.register(white_client, "ProfileWhite")
        black = self.register(black_client, "ProfileBlack")
        room = self.post(white_client, "/api/rooms", {}).get_json()
        code = room["roomCode"]
        self.assertEqual(
            black_client.post(f"/api/rooms/{code}/join", json={}).status_code, 200
        )
        finished = white_client.post(f"/api/rooms/{code}/forfeit", json={})
        self.assertEqual(finished.status_code, 200, finished.get_json())

        response = self.client.get(f"/api/users/{black['id']}/profile")
        self.assertEqual(response.status_code, 200, response.get_json())
        profile = response.get_json()["profile"]
        self.assertEqual(profile["username"], "ProfileBlack")
        self.assertGreater(profile["rating"], black["rating"])
        self.assertEqual(profile["record"], {"wins": 1, "draws": 0, "losses": 0})
        self.assertEqual(len(profile["recentGames"]), 1)
        self.assertEqual(profile["recentGames"][0]["outcome"], "win")
        self.assertEqual(profile["recentGames"][0]["opponent"], "ProfileWhite")
        self.assertGreater(profile["recentGames"][0]["ratingChange"], 0)
        self.assertIn("memberSince", profile)
        self.assertEqual(
            self.client.get("/api/users/99999/profile").status_code, 404
        )

    def test_time_control_clocks_and_increment_are_enforced(self):
        created = self.post(self.client, "/api/rooms", {"timeControl": "bullet_2_1"})
        self.assertEqual(created.status_code, 201, created.get_json())
        code = created.get_json()["roomCode"]
        waiting = self.client.get(f"/api/rooms/{code}")
        self.assertEqual(waiting.status_code, 200, waiting.get_json())
        opponent = self.app.test_client()
        joined = opponent.post(f"/api/rooms/{code}/join", json={})
        self.assertEqual(joined.status_code, 200, joined.get_json())
        self.assertEqual(joined.get_json()["timeControl"], "Bullet · 2+1")
        self.assertIsNone(joined.get_json()["clockStartedAt"])
        self.assertEqual(joined.get_json()["whiteTimeMs"], 120000)
        self.assertEqual(joined.get_json()["blackTimeMs"], 120000)

        moved = self.client.post(
            f"/api/rooms/{code}/move", json={"from": "e2", "to": "e4"}
        )
        self.assertEqual(moved.status_code, 200, moved.get_json())
        self.assertIsNotNone(moved.get_json()["clockStartedAt"])
        self.assertEqual(moved.get_json()["whiteTimeMs"], 121000)
        self.assertLessEqual(moved.get_json()["blackTimeMs"], 120000)
        self.assertGreater(moved.get_json()["blackTimeMs"], 119000)

        with self.app.app_context():
            import sqlite3
            import time

            connection = sqlite3.connect(self.database)
            connection.execute(
                """
                UPDATE games SET black_time_ms = 1, clock_started_at = ?,
                    white_last_seen_at = ?, black_last_seen_at = ? WHERE room_code = ?
                """,
                (
                    int(time.time() * 1000) - 1000,
                    int(time.time() * 1000),
                    int(time.time() * 1000),
                    code,
                ),
            )
            connection.commit()
            connection.close()
        timed_out = self.client.get(f"/api/rooms/{code}")
        self.assertEqual(timed_out.status_code, 200, timed_out.get_json())
        self.assertEqual(timed_out.get_json()["status"], "completed")
        self.assertEqual(timed_out.get_json()["result"], "White wins on time")

    def test_unknown_time_control_is_rejected(self):
        response = self.post(
            self.client, "/api/rooms", {"timeControl": "unlimited"}
        )
        self.assertEqual(response.status_code, 400)

    def test_existing_sqlite_database_is_migrated_for_ratings_and_clocks(self):
        import sqlite3

        legacy_database = Path(self.temp_dir.name) / "legacy.sqlite3"
        connection = sqlite3.connect(legacy_database)
        connection.executescript(
            """
            CREATE TABLE users (
                id INTEGER PRIMARY KEY,
                username TEXT NOT NULL UNIQUE COLLATE NOCASE,
                password_hash TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE games (
                id INTEGER PRIMARY KEY,
                room_code TEXT NOT NULL UNIQUE,
                white_user_id INTEGER,
                black_user_id INTEGER,
                white_guest_id TEXT,
                black_guest_id TEXT,
                invited_user_id INTEGER,
                moves_json TEXT NOT NULL DEFAULT '[]',
                grades_json TEXT NOT NULL DEFAULT '[]',
                result TEXT,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );
            """
        )
        connection.close()

        create_app(legacy_database, secret_key="migration-test-secret")
        connection = sqlite3.connect(legacy_database)
        user_columns = {
            row[1] for row in connection.execute("PRAGMA table_info(users)")
        }
        game_columns = {
            row[1] for row in connection.execute("PRAGMA table_info(games)")
        }
        connection.close()
        self.assertIn("rating", user_columns)
        self.assertTrue({
            "rating_changes_json",
            "time_control",
            "white_time_ms",
            "black_time_ms",
            "increment_seconds",
            "clock_started_at",
            "white_last_seen_at",
            "black_last_seen_at",
            "rematch_requested_by",
        }.issubset(game_columns))

    def test_clock_waits_until_both_players_are_present(self):
        room = self.post(self.client, "/api/rooms", {}).get_json()
        code = room["roomCode"]
        opponent = self.app.test_client()

        joined = opponent.post(f"/api/rooms/{code}/join", json={})
        self.assertEqual(joined.status_code, 200, joined.get_json())
        self.assertIsNone(joined.get_json()["clockStartedAt"])
        self.assertEqual(joined.get_json()["whiteTimeMs"], 600000)

        present = self.client.get(f"/api/rooms/{code}")
        self.assertEqual(present.status_code, 200, present.get_json())
        self.assertIsNone(present.get_json()["clockStartedAt"])
        moved = self.client.post(
            f"/api/rooms/{code}/move", json={"from": "e2", "to": "e4"}
        )
        self.assertEqual(moved.status_code, 200, moved.get_json())
        self.assertIsNotNone(moved.get_json()["clockStartedAt"])

    def test_clock_pauses_for_absent_player_and_resumes_on_return(self):
        import sqlite3
        import time

        room = self.post(self.client, "/api/rooms", {}).get_json()
        code = room["roomCode"]
        self.assertEqual(self.client.get(f"/api/rooms/{code}").status_code, 200)
        opponent = self.app.test_client()
        joined = opponent.post(f"/api/rooms/{code}/join", json={})
        self.assertEqual(joined.status_code, 200, joined.get_json())
        self.assertEqual(
            self.client.post(
                f"/api/rooms/{code}/move", json={"from": "e2", "to": "e4"}
            ).status_code,
            200,
        )
        self.assertEqual(
            opponent.post(
                f"/api/rooms/{code}/move", json={"from": "e7", "to": "e5"}
            ).status_code,
            200,
        )

        now_ms = int(time.time() * 1000)
        with self.app.app_context():
            connection = sqlite3.connect(self.database)
            connection.execute(
                """
                UPDATE games SET white_time_ms = 60000, black_time_ms = 60000,
                    clock_started_at = ?, white_last_seen_at = ?,
                    black_last_seen_at = ? WHERE room_code = ?
                """,
                (now_ms - 6000, now_ms, now_ms - 7000, code),
            )
            connection.commit()
            connection.close()

        with patch("app.time.time", return_value=now_ms / 1000):
            paused = self.client.get(f"/api/rooms/{code}").get_json()
            self.assertIsNone(paused["clockStartedAt"])
            self.assertEqual(paused["whiteTimeMs"], 56000)

            resumed = opponent.get(f"/api/rooms/{code}").get_json()
            self.assertEqual(resumed["clockStartedAt"], now_ms)
            self.assertEqual(resumed["whiteTimeMs"], 56000)

    def test_leaving_game_pauses_clock_and_returning_resumes_it(self):
        import sqlite3
        import time

        room = self.post(self.client, "/api/rooms", {}).get_json()
        code = room["roomCode"]
        self.client.get(f"/api/rooms/{code}")
        opponent = self.app.test_client()
        joined = opponent.post(f"/api/rooms/{code}/join", json={})
        self.assertEqual(joined.status_code, 200, joined.get_json())
        self.assertEqual(
            self.client.post(
                f"/api/rooms/{code}/move", json={"from": "e2", "to": "e4"}
            ).status_code,
            200,
        )
        self.assertEqual(
            opponent.post(
                f"/api/rooms/{code}/move", json={"from": "e7", "to": "e5"}
            ).status_code,
            200,
        )
        now_ms = int(time.time() * 1000)

        with self.app.app_context():
            connection = sqlite3.connect(self.database)
            connection.execute(
                """
                UPDATE games SET white_time_ms = 60000, black_time_ms = 60000,
                    clock_started_at = ?, white_last_seen_at = ?,
                    black_last_seen_at = ? WHERE room_code = ?
                """,
                (now_ms - 1000, now_ms, now_ms, code),
            )
            connection.commit()
            connection.close()

        with patch("app.time.time", return_value=now_ms / 1000):
            left = opponent.post(f"/api/rooms/{code}/leave", json={})
            self.assertEqual(left.status_code, 200, left.get_json())
            paused = self.client.get(f"/api/rooms/{code}").get_json()
            self.assertIsNone(paused["clockStartedAt"])
            self.assertEqual(paused["whiteTimeMs"], 59001)

            returned = opponent.get(f"/api/rooms/{code}").get_json()
            self.assertEqual(returned["clockStartedAt"], now_ms)
            self.assertEqual(returned["whiteTimeMs"], 59001)

    def test_accounts_start_at_800_and_elo_updates_once_after_forfeit(self):
        white_client = self.app.test_client()
        black_client = self.app.test_client()
        white = self.register(white_client, "WhitePlayer")
        black = self.register(black_client, "BlackPlayer")
        self.assertEqual(white["rating"], 800)
        self.assertEqual(black["rating"], 800)

        with self.app.app_context():
            import sqlite3

            connection = sqlite3.connect(self.database)
            connection.execute(
                "UPDATE users SET rating = 1200 WHERE id = ?", (black["id"],)
            )
            connection.commit()
            connection.close()

        room = self.post(white_client, "/api/rooms", {}).get_json()
        code = room["roomCode"]
        joined = black_client.post(f"/api/rooms/{code}/join", json={})
        self.assertEqual(joined.status_code, 200, joined.get_json())
        self.assertEqual(joined.get_json()["whiteRating"], 800)
        self.assertEqual(joined.get_json()["blackRating"], 1200)

        finished = white_client.post(f"/api/rooms/{code}/forfeit", json={})
        self.assertEqual(finished.status_code, 200, finished.get_json())
        self.assertEqual(finished.get_json()["result"], "Black wins by forfeit")
        self.assertEqual(finished.get_json()["ratingChanges"]["white"]["change"], -3)
        self.assertEqual(finished.get_json()["ratingChanges"]["black"]["change"], 3)
        self.assertEqual(white_client.get("/api/session").get_json()["user"]["rating"], 797)
        self.assertEqual(black_client.get("/api/session").get_json()["user"]["rating"], 1203)
        repeated = white_client.post(f"/api/rooms/{code}/forfeit", json={})
        self.assertEqual(repeated.status_code, 409)
        self.assertEqual(white_client.get("/api/session").get_json()["user"]["rating"], 797)

    def test_rematch_requires_opponent_acceptance(self):
        white_client = self.app.test_client()
        black_client = self.app.test_client()
        self.register(white_client, "WhiteRematch")
        self.register(black_client, "BlackRematch")
        room = self.post(white_client, "/api/rooms", {}).get_json()
        code = room["roomCode"]
        self.assertEqual(
            black_client.post(f"/api/rooms/{code}/join", json={}).status_code, 200
        )
        finished = white_client.post(f"/api/rooms/{code}/forfeit", json={})
        self.assertEqual(finished.status_code, 200, finished.get_json())

        requested = white_client.post(f"/api/rooms/{code}/new-game", json={})
        self.assertEqual(requested.status_code, 200, requested.get_json())
        self.assertEqual(requested.get_json()["status"], "completed")
        self.assertEqual(requested.get_json()["rematchRequestedBy"], "w")
        self.assertEqual(
            black_client.get(f"/api/rooms/{code}").get_json()["rematchRequestedBy"],
            "w",
        )
        rejected = white_client.post(
            f"/api/rooms/{code}/new-game/respond", json={"accept": True}
        )
        self.assertEqual(rejected.status_code, 409, rejected.get_json())

        accepted = black_client.post(
            f"/api/rooms/{code}/new-game/respond", json={"accept": True}
        )
        self.assertEqual(accepted.status_code, 200, accepted.get_json())
        self.assertEqual(accepted.get_json()["status"], "active")
        self.assertFalse(accepted.get_json()["over"])
        self.assertEqual(accepted.get_json()["history"], [])
        self.assertIsNone(accepted.get_json()["rematchRequestedBy"])

    def test_rematch_can_be_declined_or_cancelled(self):
        white_client = self.app.test_client()
        black_client = self.app.test_client()
        self.register(white_client, "WhiteCancel")
        self.register(black_client, "BlackCancel")
        room = self.post(white_client, "/api/rooms", {}).get_json()
        code = room["roomCode"]
        self.assertEqual(
            black_client.post(f"/api/rooms/{code}/join", json={}).status_code, 200
        )
        self.assertEqual(
            white_client.post(f"/api/rooms/{code}/forfeit", json={}).status_code, 200
        )

        self.assertEqual(
            white_client.post(f"/api/rooms/{code}/new-game", json={}).status_code, 200
        )
        declined = black_client.post(
            f"/api/rooms/{code}/new-game/respond", json={"accept": False}
        )
        self.assertEqual(declined.status_code, 200, declined.get_json())
        self.assertIsNone(declined.get_json()["rematchRequestedBy"])
        self.assertEqual(declined.get_json()["status"], "completed")

        self.assertEqual(
            white_client.post(f"/api/rooms/{code}/new-game", json={}).status_code, 200
        )
        cancelled = white_client.post(
            f"/api/rooms/{code}/new-game/respond", json={"accept": False}
        )
        self.assertEqual(cancelled.status_code, 200, cancelled.get_json())
        self.assertIsNone(cancelled.get_json()["rematchRequestedBy"])

    def test_friend_requests_and_invitation_join(self):
        alice_client = self.app.test_client()
        bob_client = self.app.test_client()
        alice = self.register(alice_client, "Alice_1")
        bob = self.register(bob_client, "Bob_22")

        sent = self.post(
            alice_client, "/api/friends/requests", {"userId": bob["id"]}
        )
        self.assertEqual(sent.status_code, 201, sent.get_json())
        self.assertEqual(sent.get_json()["status"], "sent")
        repeated = self.post(
            alice_client, "/api/friends/requests", {"userId": bob["id"]}
        )
        self.assertEqual(repeated.status_code, 200, repeated.get_json())
        self.assertEqual(repeated.get_json()["status"], "pending")
        self.assertEqual(
            alice_client.get("/api/dashboard").get_json()["sentRequests"][0]["user_id"],
            bob["id"],
        )
        request_id = bob_client.get("/api/dashboard").get_json()["requests"][0]["id"]
        accepted = self.post(
            bob_client, f"/api/friends/requests/{request_id}", {"accept": True}
        )
        self.assertEqual(accepted.status_code, 200)
        self.assertEqual(
            alice_client.get("/api/dashboard").get_json()["friends"][0]["id"],
            bob["id"],
        )

        with patch("app.secrets.randbelow", return_value=0):
            invite_response = self.post(
                alice_client, "/api/invitations", {"friendId": bob["id"]}
            )
        self.assertEqual(invite_response.status_code, 201, invite_response.get_json())
        self.assertEqual(invite_response.get_json()["playerSide"], "w")
        code = invite_response.get_json()["roomCode"]
        self.assertEqual(
            bob_client.get("/api/dashboard").get_json()["invitations"][0]["room_code"],
            code,
        )
        preview = bob_client.get(f"/api/rooms/{code}")
        self.assertEqual(preview.status_code, 200, preview.get_json())
        self.assertTrue(preview.get_json()["requiresAcceptance"])
        self.assertEqual(preview.get_json()["status"], "waiting")
        self.assertEqual(alice_client.get(f"/api/rooms/{code}").get_json()["status"], "waiting")
        joined = bob_client.post(f"/api/rooms/{code}/join", json={})
        self.assertEqual(joined.status_code, 200, joined.get_json())
        self.assertEqual(joined.get_json()["status"], "active")
        self.assertEqual(joined.get_json()["playerSide"], "b")

    def test_invite_can_assign_inviter_black_and_remains_closable(self):
        alice_client = self.app.test_client()
        bob_client = self.app.test_client()
        alice = self.register(alice_client, "Alice_1")
        bob = self.register(bob_client, "Bob_22")
        self.post(alice_client, "/api/friends/requests", {"username": bob["username"]})
        request_id = bob_client.get("/api/dashboard").get_json()["requests"][0]["id"]
        self.post(bob_client, f"/api/friends/requests/{request_id}", {"accept": True})

        with patch("app.secrets.randbelow", return_value=1):
            invite = self.post(
                alice_client, "/api/invitations", {"friendId": bob["id"]}
            ).get_json()
        self.assertEqual(invite["playerSide"], "b")
        preview = bob_client.get(f"/api/rooms/{invite['roomCode']}").get_json()
        self.assertTrue(preview["requiresAcceptance"])
        self.assertEqual(preview["playerSide"], "w")
        self.assertFalse(preview["canCloseWaitingRoom"])
        owner_preview = alice_client.get(
            f"/api/rooms/{invite['roomCode']}"
        ).get_json()
        self.assertTrue(owner_preview["canCloseWaitingRoom"])
        alice_client.post(f"/api/rooms/{invite['roomCode']}/leave", json={})
        self.assertEqual(
            bob_client.get("/api/dashboard").get_json()["invitations"][0]["room_code"],
            invite["roomCode"],
        )
        self.assertEqual(
            alice_client.post(
                f"/api/rooms/{invite['roomCode']}/close", json={}
            ).status_code,
            200,
        )
        self.assertEqual(
            bob_client.get("/api/dashboard").get_json()["invitations"],
            [],
        )

        with patch("app.secrets.randbelow", return_value=1):
            joined_invite = self.post(
                alice_client, "/api/invitations", {"friendId": bob["id"]}
            ).get_json()
        joined = bob_client.post(
            f"/api/rooms/{joined_invite['roomCode']}/join", json={}
        )
        self.assertEqual(joined.status_code, 200, joined.get_json())
        self.assertEqual(joined.get_json()["playerSide"], "w")

    def test_stockfish_bot_room_and_legal_bot_moves(self):
        created = self.post(self.client, "/api/bot-games", {
            "botElo": 1000,
            "timeControl": "blitz_3_0",
        })
        self.assertEqual(created.status_code, 201, created.get_json())
        code = created.get_json()["roomCode"]
        initial = self.client.get(f"/api/rooms/{code}").get_json()
        self.assertEqual(initial["status"], "active")
        self.assertEqual(initial["botElo"], 1000)
        self.assertEqual(initial["blackName"], "Stockfish (1000 Elo)")
        self.assertEqual(initial["blackRating"], 1000)

        player_move = self.post(self.client, f"/api/rooms/{code}/move", {
            "from": "e2",
            "to": "e4",
        })
        self.assertEqual(player_move.status_code, 200, player_move.get_json())
        bot_move = self.post(self.client, f"/api/rooms/{code}/bot-move", {
            "from": "e7",
            "to": "e5",
        })
        self.assertEqual(bot_move.status_code, 200, bot_move.get_json())
        self.assertEqual(bot_move.get_json()["turn"], "w")
        self.assertEqual(len(bot_move.get_json()["history"]), 2)

        illegal_bot_move = self.post(self.client, f"/api/rooms/{code}/bot-move", {
            "from": "e7",
            "to": "e5",
        })
        self.assertEqual(illegal_bot_move.status_code, 403)
        invalid_bot = self.post(self.client, "/api/bot-games", {"botElo": 900})
        self.assertEqual(invalid_bot.status_code, 400)

        karti_room = self.post(self.client, "/api/bot-games", {
            "botElo": 1600,
        }).get_json()
        karti_state = self.client.get(
            f"/api/rooms/{karti_room['roomCode']}"
        ).get_json()
        self.assertEqual(karti_state["blackName"], "Karti")

    def test_account_shop_daily_coins_skin_purchases_and_equipping(self):
        self.assertEqual(self.client.get("/api/shop").status_code, 401)
        self.assertEqual(
            self.post(self.client, "/api/shop/daily", {}).status_code, 401
        )
        self.register(self.client, "ShopPlayer")

        shop = self.client.get("/api/shop")
        self.assertEqual(shop.status_code, 200, shop.get_json())
        initial = shop.get_json()
        self.assertEqual(initial["coins"], 0)
        self.assertTrue(initial["canClaimDaily"])
        self.assertEqual(len(initial["skins"]["board"]), 9)
        self.assertEqual(
            [(skin["id"], skin["price"]) for skin in initial["skins"]["board"][-3:]],
            [("rosewood", 100), ("monochrome", 100), ("nebula", 500)],
        )
        self.assertEqual(initial["skins"]["board"][-1]["name"], "Celestial Atlas")
        self.assertEqual(len(initial["skins"]["piece"]), 8)
        self.assertEqual(
            [skin["id"] for skin in initial["skins"]["piece"][-2:]],
            ["spatial", "chessnut"],
        )
        self.assertTrue(initial["skins"]["board"][0]["owned"])
        self.assertTrue(initial["skins"]["piece"][0]["owned"])

        claimed = self.post(self.client, "/api/shop/daily", {})
        self.assertEqual(claimed.status_code, 200, claimed.get_json())
        self.assertEqual(claimed.get_json()["coins"], 100)
        self.assertFalse(claimed.get_json()["canClaimDaily"])
        repeated_claim = self.post(self.client, "/api/shop/daily", {})
        self.assertEqual(repeated_claim.status_code, 409)

        purchased = self.post(self.client, "/api/shop/purchase", {
            "type": "board",
            "skinId": "grove",
        })
        self.assertEqual(purchased.status_code, 200, purchased.get_json())
        self.assertEqual(purchased.get_json()["coins"], 0)
        self.assertTrue(next(
            skin for skin in purchased.get_json()["skins"]["board"]
            if skin["id"] == "grove"
        )["owned"])
        self.assertEqual(
            self.post(self.client, "/api/shop/purchase", {
                "type": "board", "skinId": "grove",
            }).status_code,
            409,
        )
        equipped = self.post(self.client, "/api/shop/equip", {
            "type": "board",
            "skinId": "grove",
        })
        self.assertEqual(equipped.status_code, 200, equipped.get_json())
        self.assertEqual(equipped.get_json()["boardSkin"], "grove")
        self.assertEqual(
            self.post(self.client, "/api/shop/equip", {
                "type": "piece", "skinId": "rose",
            }).status_code,
            403,
        )

        room = self.post(self.client, "/api/rooms", {}).get_json()
        snapshot = self.client.get(f"/api/rooms/{room['roomCode']}").get_json()
        self.assertEqual(snapshot["whiteBoardSkin"], "grove")
        self.assertEqual(snapshot["whitePieceSkin"], "classic")
        self.assertEqual(snapshot["blackBoardSkin"], "classic")

    def test_owner_special_skin_is_visible_but_only_zand_can_equip_it(self):
        guest_page_response = self.client.get("/")
        guest_page = guest_page_response.get_data(as_text=True)
        guest_page_response.close()
        self.assertIn("OWNER-ONLY COLLECTION", guest_page)
        self.assertIn("owner-skin-list", guest_page)

        self.register(self.client, "RegularPlayer")
        shop = self.client.get("/api/shop").get_json()
        special = shop["specialSkins"][0]
        self.assertEqual(special["id"], "golden")
        self.assertFalse(special["owned"])
        self.assertFalse(special["equipped"])
        self.assertTrue(special["ownerOnly"])
        self.assertEqual(
            self.post(self.client, "/api/shop/purchase", {
                "type": "piece", "skinId": "golden",
            }).status_code,
            403,
        )
        self.assertEqual(
            self.post(self.client, "/api/shop/equip", {
                "type": "piece", "skinId": "golden",
            }).status_code,
            403,
        )

        owner = self.app.test_client()
        self.register(owner, "zand")
        owner_skin = owner.get("/api/shop").get_json()["specialSkins"][0]
        self.assertTrue(owner_skin["owned"])
        equipped = self.post(owner, "/api/shop/equip", {
            "type": "piece", "skinId": "golden",
        })
        self.assertEqual(equipped.status_code, 200, equipped.get_json())
        self.assertTrue(equipped.get_json()["specialSkins"][0]["equipped"])
        room = self.post(owner, "/api/rooms", {}).get_json()
        snapshot = owner.get(f"/api/rooms/{room['roomCode']}").get_json()
        self.assertEqual(snapshot["whitePieceSkin"], "golden")

    def test_removed_kiwen_suwi_skin_is_reset_during_database_migration(self):
        account = self.register(self.client, "LegacySkin")
        connection = sqlite3.connect(self.database)
        connection.execute(
            "UPDATE users SET piece_skin = 'kiwen-suwi' WHERE id = ?",
            (account["id"],),
        )
        connection.execute(
            """
            INSERT INTO user_skins(user_id, skin_type, skin_id)
            VALUES (?, 'piece', 'kiwen-suwi')
            """,
            (account["id"],),
        )
        connection.commit()
        connection.close()

        create_app(self.database, secret_key="test-secret-key")
        connection = sqlite3.connect(self.database)
        skin = connection.execute(
            "SELECT piece_skin FROM users WHERE id = ?", (account["id"],)
        ).fetchone()[0]
        owned = connection.execute(
            "SELECT COUNT(*) FROM user_skins WHERE user_id = ? AND skin_id = 'kiwen-suwi'",
            (account["id"],),
        ).fetchone()[0]
        connection.close()
        self.assertEqual(skin, "classic")
        self.assertEqual(owned, 0)

    def test_replaced_piece_skins_keep_existing_ownership_and_equipped_skin(self):
        account = self.register(self.client, "LegacyPieceSets")
        connection = sqlite3.connect(self.database)
        connection.execute(
            "UPDATE users SET piece_skin = 'fantasy' WHERE id = ?",
            (account["id"],),
        )
        connection.executemany(
            """
            INSERT INTO user_skins(user_id, skin_type, skin_id)
            VALUES (?, 'piece', ?)
            """,
            [
                (account["id"], "fantasy"),
                (account["id"], "celtic"),
                (account["id"], "spatial"),
            ],
        )
        connection.commit()
        connection.close()

        create_app(self.database, secret_key="test-secret-key")
        connection = sqlite3.connect(self.database)
        skin = connection.execute(
            "SELECT piece_skin FROM users WHERE id = ?", (account["id"],)
        ).fetchone()[0]
        owned = {
            row[0] for row in connection.execute(
                "SELECT skin_id FROM user_skins "
                "WHERE user_id = ? AND skin_type = 'piece'",
                (account["id"],),
            )
        }
        connection.close()
        self.assertEqual(skin, "spatial")
        self.assertEqual(owned, {"spatial", "chessnut"})

    def test_removed_glacier_board_skin_migrates_to_monochrome(self):
        account = self.register(self.client, "LegacyGlacier")
        connection = sqlite3.connect(self.database)
        connection.execute(
            "UPDATE users SET board_skin = 'glacier' WHERE id = ?",
            (account["id"],),
        )
        connection.execute(
            """
            INSERT INTO user_skins(user_id, skin_type, skin_id)
            VALUES (?, 'board', 'glacier')
            """,
            (account["id"],),
        )
        connection.commit()
        connection.close()

        create_app(self.database, secret_key="test-secret-key")
        connection = sqlite3.connect(self.database)
        skin = connection.execute(
            "SELECT board_skin FROM users WHERE id = ?", (account["id"],)
        ).fetchone()[0]
        owned = {
            row[0] for row in connection.execute(
                "SELECT skin_id FROM user_skins "
                "WHERE user_id = ? AND skin_type = 'board'",
                (account["id"],),
            )
        }
        connection.close()
        self.assertEqual(skin, "monochrome")
        self.assertEqual(owned, {"monochrome"})

    def test_player_game_coins_use_elo_and_limit_repeat_opponent_rewards(self):
        self.register(self.client, "RewardWhite")
        opponent = self.app.test_client()
        opponent_account = self.register(opponent, "RewardBlack")
        connection = sqlite3.connect(self.database)
        connection.execute(
            "UPDATE users SET rating = 1100 WHERE id = ?",
            (opponent_account["id"],),
        )
        connection.commit()
        connection.close()

        room = self.post(self.client, "/api/rooms", {}).get_json()
        code = room["roomCode"]
        self.assertEqual(
            self.post(opponent, f"/api/rooms/{code}/join", {}).status_code, 200
        )
        moves = ["e2e4", "e7e5", "g1f3", "b8c6", "f1b5", "a7a6", "b5a4", "g8f6"]
        connection = sqlite3.connect(self.database)
        connection.execute(
            "UPDATE games SET moves_json = ? WHERE room_code = ?",
            (json.dumps(moves), code),
        )
        connection.commit()
        connection.close()

        finished = self.post(opponent, f"/api/rooms/{code}/forfeit", {})
        self.assertEqual(finished.status_code, 200, finished.get_json())
        first_snapshot = self.client.get(f"/api/rooms/{code}").get_json()
        self.assertEqual(first_snapshot["coinsEarned"], 38)
        self.assertEqual(self.client.get("/api/shop").get_json()["coins"], 38)
        loser_snapshot = opponent.get(f"/api/rooms/{code}").get_json()
        self.assertEqual(loser_snapshot["coinsEarned"], 19)
        self.assertEqual(opponent.get("/api/shop").get_json()["coins"], 19)

        self.post(self.client, f"/api/rooms/{code}/new-game", {})
        accepted = self.post(
            opponent, f"/api/rooms/{code}/new-game/respond", {"accept": True}
        )
        self.assertEqual(accepted.status_code, 200, accepted.get_json())
        connection = sqlite3.connect(self.database)
        connection.execute(
            "UPDATE games SET moves_json = ? WHERE room_code = ?",
            (json.dumps(moves), code),
        )
        connection.commit()
        connection.close()
        finished = self.post(opponent, f"/api/rooms/{code}/forfeit", {})
        self.assertEqual(finished.status_code, 200, finished.get_json())
        second_snapshot = self.client.get(f"/api/rooms/{code}").get_json()
        self.assertEqual(second_snapshot["coinsEarned"], 0)
        self.assertEqual(self.client.get("/api/shop").get_json()["coins"], 38)
        self.assertEqual(
            opponent.get(f"/api/rooms/{code}").get_json()["coinsEarned"], 0
        )
        self.assertEqual(opponent.get("/api/shop").get_json()["coins"], 19)

    def test_bot_game_coins_are_modest_and_awarded_to_the_account_winner(self):
        self.register(self.client, "BotReward")
        room = self.post(self.client, "/api/bot-games", {"botElo": 1600}).get_json()
        moves = ["e2e4", "e7e5", "g1f3", "b8c6", "f1b5", "a7a6", "b5a4", "g8f6"]
        with self.app.app_context():
            connection = database()
            game = load_room(room["roomCode"])
            connection.execute(
                """
                UPDATE games SET moves_json = ?, status = 'completed',
                    result = 'White wins by forfeit' WHERE id = ?
                """,
                (json.dumps(moves), game["id"]),
            )
            rate_completed_game(connection, game, "White wins by forfeit")
            connection.commit()
            connection.close()
        snapshot = self.client.get(f"/api/rooms/{room['roomCode']}").get_json()
        self.assertEqual(snapshot["coinsEarned"], 5)
        self.assertEqual(self.client.get("/api/shop").get_json()["coins"], 5)

    def test_dashboard_notifies_inviter_when_opponent_is_present(self):
        alice_client = self.app.test_client()
        bob_client = self.app.test_client()
        alice = self.register(alice_client, "Alice_1")
        bob = self.register(bob_client, "Bob_22")
        self.post(alice_client, "/api/friends/requests", {"username": bob["username"]})
        request_id = bob_client.get("/api/dashboard").get_json()["requests"][0]["id"]
        self.post(bob_client, f"/api/friends/requests/{request_id}", {"accept": True})
        invite = self.post(
            alice_client, "/api/invitations", {"friendId": bob["id"]}
        ).get_json()

        before = alice_client.get("/api/dashboard").get_json()
        invite_game = next(
            game for game in before["games"]
            if game["room_code"] == invite["roomCode"]
        )
        self.assertTrue(invite_game["is_creator"])
        self.assertFalse(invite_game["opponent_present"])

        preview = bob_client.get(f"/api/rooms/{invite['roomCode']}").get_json()
        self.assertTrue(preview["requiresAcceptance"])
        self.assertEqual(preview["status"], "waiting")
        after = alice_client.get("/api/dashboard").get_json()
        invite_game = next(
            game for game in after["games"]
            if game["room_code"] == invite["roomCode"]
        )
        self.assertTrue(invite_game["opponent_present"])
        self.assertEqual(invite_game["status"], "waiting")

        joined = bob_client.post(
            f"/api/rooms/{invite['roomCode']}/join", json={}
        )
        self.assertEqual(joined.status_code, 200, joined.get_json())
        accepted = alice_client.get("/api/dashboard").get_json()
        invite_game = next(
            game for game in accepted["games"]
            if game["room_code"] == invite["roomCode"]
        )
        self.assertEqual(invite_game["status"], "active")

    def test_invite_room_rejects_non_invited_user(self):
        alice_client = self.app.test_client()
        bob_client = self.app.test_client()
        charlie_client = self.app.test_client()
        self.register(alice_client, "Alice_1")
        bob = self.register(bob_client, "Bob_22")
        charlie = self.register(charlie_client, "Charlie3")
        self.post(alice_client, "/api/friends/requests", {"username": bob["username"]})
        request_id = bob_client.get("/api/dashboard").get_json()["requests"][0]["id"]
        self.post(bob_client, f"/api/friends/requests/{request_id}", {"accept": True})
        invitation = self.post(
            alice_client, "/api/invitations", {"friendId": bob["id"]}
        ).get_json()

        response = charlie_client.post(
            f"/api/rooms/{invitation['roomCode']}/join", json={}
        )
        self.assertEqual(response.status_code, 403)
        self.assertNotEqual(charlie["id"], bob["id"])

    def test_accounts_require_valid_password_and_hash_credentials(self):
        weak_password = self.post(self.client, "/api/register", {
            "username": "NewPlayer",
            "password": "short",
        })
        self.assertEqual(weak_password.status_code, 400)
        self.register(self.client, "NewPlayer")
        with self.app.app_context():
            import sqlite3

            connection = sqlite3.connect(self.database)
            password_hash = connection.execute(
                "SELECT password_hash FROM users WHERE username = 'NewPlayer'"
            ).fetchone()[0]
            connection.close()
        self.assertNotEqual(password_hash, "correct horse battery staple")


if __name__ == "__main__":
    unittest.main()
