import tkinter as tk
import time
import unittest

from chess_gui import ChessWindow, analyze_move, calculate_elo, rate_move
from two_player_chess import ChessGame, Move


class EloTests(unittest.TestCase):
    def test_equal_ratings_change_by_sixteen_after_a_win(self) -> None:
        self.assertEqual(calculate_elo(1200, 1200, 1.0), (1216, 1184))

    def test_equal_ratings_do_not_change_after_a_draw(self) -> None:
        self.assertEqual(calculate_elo(1200, 1200, 0.5), (1200, 1200))

    def test_rejects_invalid_score(self) -> None:
        with self.assertRaises(ValueError):
            calculate_elo(1200, 1200, 0.25)


class MoveRatingTests(unittest.TestCase):
    def test_move_rating_is_a_named_heuristic_category(self) -> None:
        game = ChessGame()
        move = next(
            move for move in game.legal_moves()
            if game.square_name(move.start) == "e2"
            and game.square_name(move.end) == "e4"
        )
        self.assertIn(
            rate_move(game, move),
            {
                "Best", "Great", "Excellent", "Good", "Inaccuracy",
                "Mistake", "Blunder", "Missed win",
            },
        )
        rating, centipawn_loss = analyze_move(game, move)
        self.assertEqual(rating, "Best")
        self.assertEqual(centipawn_loss, 0)

    def test_rejects_a_move_that_is_not_legal(self) -> None:
        game = ChessGame()
        illegal_move = Move((6, 4), (3, 4))
        with self.assertRaises(ValueError):
            analyze_move(game, illegal_move)


class BoardOrientationTests(unittest.TestCase):
    def test_orientation_follows_side_to_move_and_clicks_still_map(self) -> None:
        root = tk.Tk()
        root.geometry("900x680")
        try:
            window = ChessWindow(root)
            root.update()

            left, top, right, _bottom = window.board_bounds
            square_size = (right - left) / 8
            window.on_board_click(type("Event", (), {
                "x": int(left + 4.5 * square_size),
                "y": int(top + 6.5 * square_size),
            })())
            window.on_board_click(type("Event", (), {
                "x": int(left + 4.5 * square_size),
                "y": int(top + 4.5 * square_size),
            })())

            self.assertTrue(window.flipped)
            self.assertEqual(window.game.turn, "b")
            self.assertEqual(window.game.board[4][4], "P")

            left, top, right, _bottom = window.board_bounds
            square_size = (right - left) / 8
            window.on_board_click(type("Event", (), {
                "x": int(left + 3.5 * square_size),
                "y": int(top + 6.5 * square_size),
            })())
            window.on_board_click(type("Event", (), {
                "x": int(left + 3.5 * square_size),
                "y": int(top + 4.5 * square_size),
            })())
            self.assertFalse(window.flipped)
            self.assertEqual(window.game.turn, "w")
            self.assertEqual(window.game.board[3][4], "p")
        finally:
            root.destroy()


class CaptureAnimationTests(unittest.TestCase):
    def test_capture_animation_tracks_resizing_and_finishes_cleanly(self) -> None:
        root = tk.Tk()
        root.geometry("900x680")
        try:
            window = ChessWindow(root)
            root.update()
            window.animate_capture("q", (4, 4))
            root.update()
            self.assertTrue(window.canvas.find_withtag("capture_fx_1"))

            first_bounds = window.board_bounds
            root.geometry("700x560")
            root.update()
            self.assertNotEqual(window.board_bounds, first_bounds)
            self.assertTrue(window.canvas.find_withtag("capture_fx_1"))

            started, square, piece, animation_id = window.capture_animations[0]
            window.capture_animations[0] = (
                time.monotonic() - 1, square, piece, animation_id
            )
            window.draw_board()
            self.assertFalse(window.capture_animations)
            self.assertFalse(window.canvas.find_withtag("capture_fx_1"))
        finally:
            if "window" in locals() and window.animation_job is not None:
                root.after_cancel(window.animation_job)
            root.destroy()


if __name__ == "__main__":
    unittest.main()
