import unittest

from two_player_chess import ChessGame


class ChessGameTests(unittest.TestCase):
    def play_moves(self, game: ChessGame, *moves: str) -> None:
        for move in moves:
            played, message = game.play(move)
            self.assertTrue(played, f"{move}: {message}")

    def test_starting_position_has_twenty_legal_moves(self) -> None:
        self.assertEqual(len(ChessGame().legal_moves()), 20)

    def test_rejects_illegal_move_without_changing_position(self) -> None:
        game = ChessGame()
        original_position = game.position_key()
        played, _ = game.play("e2e5")
        self.assertFalse(played)
        self.assertEqual(game.position_key(), original_position)

    def test_castling_moves_rook_and_removes_right(self) -> None:
        game = ChessGame()
        self.play_moves(game, "e2e4", "e7e5", "g1f3", "b8c6", "f1e2", "g8f6", "e1g1")
        self.assertEqual(game.board[7][6], "K")
        self.assertEqual(game.board[7][5], "R")
        self.assertNotIn("K", game.castling_rights)

    def test_en_passant_captures_pawn(self) -> None:
        game = ChessGame()
        self.play_moves(game, "e2e4", "a7a6", "e4e5", "d7d5", "e5d6")
        self.assertEqual(game.board[2][3], "P")
        self.assertEqual(game.board[3][3], ".")

    def test_promotion_defaults_to_queen_and_accepts_choice(self) -> None:
        game = ChessGame()
        game.board = [["." for _ in range(8)] for _ in range(8)]
        game.board[7][4] = "K"
        game.board[0][4] = "k"
        game.board[1][0] = "P"
        played, message = game.play("a7a8")
        self.assertTrue(played, message)
        self.assertEqual(game.board[0][0], "Q")

    def test_scholars_mate_is_checkmate(self) -> None:
        game = ChessGame()
        self.play_moves(game, "e2e4", "e7e5", "f1c4", "b8c6", "d1h5", "g8f6", "h5f7")
        self.assertEqual(game.game_over_message(), "Checkmate! White wins.")

    def test_threefold_repetition_is_a_draw(self) -> None:
        game = ChessGame()
        self.play_moves(game, "g1f3", "g8f6", "f3g1", "f6g8",
                        "g1f3", "g8f6", "f3g1", "f6g8")
        self.assertEqual(game.game_over_message(), "Draw by threefold repetition.")


if __name__ == "__main__":
    unittest.main()
