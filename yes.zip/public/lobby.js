"use strict";

const message = document.querySelector("#message");
const accountPanel = document.querySelector("#account-panel");
const friendsPanel = document.querySelector("#friends-panel");
const accountForm = document.querySelector("#account-form");
let isRegistering = false;
let signedInUser = null;
let friendIds = new Set();
let sentFriendIds = new Set();
let incomingFriendRequests = new Map();
let dashboardTimer = null;
let globalChatTimer = null;
let globalChatKey = "";
let globalChatLastMessageId = null;
let globalChatInitialized = false;
let inviteUrl = "";
let inviteTimeResolver = null;
const notifiedInvitationCodes = new Set();
const pendingInvitationPrompts = [];
let activeInvitationPrompt = null;
let activeView = "home";
let shopState = null;
const ownerSkinPreview = [{
  id: "golden",
  name: "Golden Sovereign",
  price: 0,
  owned: false,
  equipped: false,
  ownerOnly: true,
}];

async function api(path, options = {}) {
  const response = await fetch(path, {
    ...options,
    headers: { "Content-Type": "application/json", ...options.headers },
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || "The request failed.");
  return result;
}

function tell(text) {
  message.textContent = text;
}

function button(text, action, primary = false) {
  const element = document.createElement("button");
  element.type = "button";
  element.className = `button${primary ? " primary" : ""}`;
  element.textContent = text;
  element.addEventListener("click", action);
  return element;
}

function item(container, label, actionLabel, action, primary = false) {
  const row = document.createElement("div");
  row.className = "list-item";
  const name = document.createElement("span");
  name.textContent = label;
  row.append(name, button(actionLabel, action, primary));
  container.append(row);
}

function closeInviteTimePicker(timeControl = null) {
  document.querySelector("#invite-time-modal").classList.add("hidden");
  if (inviteTimeResolver) {
    inviteTimeResolver(timeControl);
    inviteTimeResolver = null;
  }
}

function openInviteTimePicker(username) {
  const modal = document.querySelector("#invite-time-modal");
  const options = document.querySelector("#invite-time-options");
  const selectedValue = document.querySelector("#time-control").value;
  options.replaceChildren();
  for (const group of document.querySelector("#time-control").querySelectorAll("optgroup")) {
    const section = document.createElement("fieldset");
    section.className = "invite-time-group";
    const legend = document.createElement("legend");
    legend.textContent = group.label;
    section.append(legend);
    for (const option of group.querySelectorAll("option")) {
      const label = document.createElement("label");
      label.className = "invite-time-option";
      const radio = document.createElement("input");
      radio.type = "radio";
      radio.name = "invite-time-control";
      radio.value = option.value;
      radio.checked = option.value === selectedValue;
      const description = document.createElement("span");
      description.textContent = option.textContent;
      label.append(radio, description);
      section.append(label);
    }
    options.append(section);
  }
  document.querySelector("#invite-time-opponent").textContent =
    `Choose a clock for your game with ${username}.`;
  modal.classList.remove("hidden");
  modal.querySelector('input[type="radio"]:checked')?.focus();
  return new Promise((resolve) => {
    inviteTimeResolver = resolve;
  });
}

function showNextInvitationPrompt() {
  if (activeInvitationPrompt || !pendingInvitationPrompts.length) return;
  activeInvitationPrompt = pendingInvitationPrompts.shift();
  document.querySelector("#join-prompt-message").textContent =
    `${activeInvitationPrompt.inviter} is waiting for you. Join their game when you’re ready.`;
  document.querySelector("#join-prompt-modal").classList.remove("hidden");
}

function queueInvitationPrompts(invitations) {
  for (const invite of invitations) {
    if (notifiedInvitationCodes.has(invite.room_code)) continue;
    notifiedInvitationCodes.add(invite.room_code);
    pendingInvitationPrompts.push(invite);
  }
  showNextInvitationPrompt();
}

async function joinInvitation(invite) {
  await api(`/api/rooms/${encodeURIComponent(invite.room_code)}/join`, {
    method: "POST", body: "{}",
  });
  window.location.href = `/play?room=${encodeURIComponent(invite.room_code)}`;
}

function leaderboardEntry(container, leader) {
  const row = document.createElement("div");
  row.className = "leaderboard-entry";
  const summary = document.createElement("button");
  summary.type = "button";
  summary.className = "leaderboard-summary";
  const rank = document.createElement("span");
  rank.className = "leaderboard-rank";
  rank.textContent = String(leader.rank).padStart(2, "0");
  const identity = document.createElement("span");
  identity.className = "leaderboard-identity";
  const name = document.createElement("strong");
  name.textContent = leader.username;
  const hint = document.createElement("small");
  hint.textContent = "View player options";
  identity.append(name, hint);
  const rating = document.createElement("strong");
  rating.className = "leaderboard-rating";
  rating.textContent = `${leader.rating} ELO`;
  summary.append(rank, identity, rating);

  const actions = document.createElement("div");
  actions.className = "leaderboard-actions hidden";
  const profileButton = button("View profile", () => {
    openPlayerProfile(leader.id).catch((error) => tell(error.message));
  });
  const friendId = Number(leader.id);
  const incomingRequestId = incomingFriendRequests.get(friendId);
  const sendFriendRequest = async () => {
    if (!signedInUser) {
      tell("Sign in to send a friend request.");
      return;
    }
    friendButton.disabled = true;
    friendButton.textContent = incomingRequestId === undefined ? "Sending…" : "Accepting…";
    try {
      if (incomingRequestId !== undefined) {
        await api(`/api/friends/requests/${incomingRequestId}`, {
          method: "POST",
          body: JSON.stringify({ accept: true }),
        });
        tell(`You and ${leader.username} are now friends.`);
      } else {
        const result = await api("/api/friends/requests", {
          method: "POST",
          body: JSON.stringify({ userId: friendId }),
        });
        tell(result.status === "friends"
          ? `You and ${leader.username} are now friends.`
          : `Friend request sent to ${leader.username}.`);
      }
      await loadDashboard();
    } catch (error) {
      friendButton.disabled = false;
      friendButton.textContent = "Send friend request";
      tell(error.message);
    }
  };
  const friendButton = button("Send friend request", sendFriendRequest, true);
  if (!signedInUser) {
    friendButton.textContent = "Sign in to add";
    friendButton.disabled = true;
    friendButton.title = "Sign in to send friend requests.";
  } else if (friendIds.has(friendId)) {
    friendButton.textContent = "Friends";
    friendButton.disabled = true;
    friendButton.title = "You are already friends.";
  } else if (signedInUser.id === friendId) {
    friendButton.textContent = "Your account";
    friendButton.disabled = true;
    friendButton.title = "This is your account.";
  } else if (incomingRequestId !== undefined) {
    friendButton.textContent = "Accept request";
  } else if (sentFriendIds.has(friendId)) {
    friendButton.textContent = "Request sent";
    friendButton.disabled = true;
    friendButton.title = "Your friend request is waiting for a response.";
  }
  actions.append(profileButton, friendButton);
  summary.addEventListener("click", () => {
    const isOpen = !actions.classList.contains("hidden");
    for (const menu of container.querySelectorAll(".leaderboard-actions")) {
      menu.classList.add("hidden");
    }
    actions.classList.toggle("hidden", isOpen);
    summary.setAttribute("aria-expanded", String(!isOpen));
  });
  summary.setAttribute("aria-expanded", "false");
  row.append(summary, actions);
  container.append(row);
}

async function loadLeaderboard() {
  const container = document.querySelector("#leaderboard-list");
  try {
    const data = await api("/api/leaderboard");
    container.replaceChildren();
    if (!data.leaders.length) {
      container.innerHTML = '<p class="muted">No accounts yet. Create an account to claim the first spot.</p>';
      return;
    }
    data.leaders.forEach((leader, index) => {
      leaderboardEntry(container, { ...leader, rank: index + 1 });
    });
  } catch (error) {
    container.replaceChildren();
    const status = document.createElement("p");
    status.className = "muted";
    status.textContent = error.message;
    container.append(status);
  }
}

async function loadLiveMatches() {
  const container = document.querySelector("#live-matches-list");
  try {
    const { matches } = await api("/api/live-matches");
    container.replaceChildren();
    if (!matches.length) {
      container.innerHTML = '<p class="muted">No live matches right now. Check back soon.</p>';
      return;
    }
    for (const match of matches) {
      const row = document.createElement("div");
      row.className = "live-match-item";
      const detail = document.createElement("div");
      detail.className = "live-match-detail";
      const players = document.createElement("strong");
      players.textContent = `${match.whiteName} vs ${match.blackName}`;
      const meta = document.createElement("span");
      const moves = match.movesPlayed === 1 ? "1 move" : `${match.movesPlayed} moves`;
      meta.textContent = `${match.timeControl} · ${moves}`;
      detail.append(players, meta);
      row.append(detail, button("Spectate", () => {
        window.location.href =
          `/play?room=${encodeURIComponent(match.roomCode)}&spectate=1`;
      }, true));
      container.append(row);
    }
  } catch (error) {
    container.replaceChildren();
    const status = document.createElement("p");
    status.className = "muted";
    status.textContent = error.message;
    container.append(status);
  }
}

function formatProfileDate(value) {
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? "Date unavailable"
    : new Intl.DateTimeFormat(undefined, { dateStyle: "medium" }).format(date);
}

async function openPlayerProfile(userId) {
  const { profile } = await api(`/api/users/${encodeURIComponent(userId)}/profile`);
  document.querySelector("#profile-name").textContent = profile.username;
  document.querySelector("#profile-member").textContent =
    `Member since ${formatProfileDate(profile.memberSince)}`;
  document.querySelector("#profile-rating").textContent = profile.rating;
  document.querySelector("#profile-wins").textContent = profile.record.wins;
  document.querySelector("#profile-draws").textContent = profile.record.draws;
  document.querySelector("#profile-losses").textContent = profile.record.losses;

  const games = document.querySelector("#profile-games");
  games.replaceChildren();
  if (!profile.recentGames.length) {
    const empty = document.createElement("p");
    empty.className = "muted";
    empty.textContent = "No completed matches yet.";
    games.append(empty);
  }
  for (const game of profile.recentGames) {
    const row = document.createElement("div");
    row.className = `profile-game ${game.outcome}`;
    const outcome = document.createElement("strong");
    outcome.className = "profile-outcome";
    outcome.textContent = game.outcome.toUpperCase();
    const detail = document.createElement("span");
    detail.className = "profile-game-detail";
    const opponent = document.createElement("strong");
    opponent.textContent = `vs ${game.opponent}`;
    const result = document.createElement("small");
    result.textContent = `${game.result} · ${formatProfileDate(game.playedAt)}`;
    detail.append(opponent, result);
    const change = document.createElement("span");
    change.className = "profile-rating-change";
    if (game.ratingChange === null) {
      change.textContent = "—";
    } else {
      change.textContent = `${game.ratingChange >= 0 ? "+" : ""}${game.ratingChange}`;
      change.classList.add(game.ratingChange >= 0 ? "positive" : "negative");
    }
    row.append(outcome, detail, change);
    games.append(row);
  }
  document.querySelector("#profile-modal").classList.remove("hidden");
}

function globalChatStatus(text) {
  document.querySelector("#global-chat-status").textContent = text;
}

function updateGlobalChatCharacterCount() {
  const input = document.querySelector("#global-chat-input");
  const counter = document.querySelector("#global-chat-character-count");
  counter.textContent = `${input.value.length} / 280`;
  counter.classList.toggle("near-limit", input.value.length >= 250);
}

function globalChatAction(text, action, disabled = false, primary = false) {
  const control = button(text, action, primary);
  control.disabled = disabled;
  return control;
}

function renderGlobalChat(messages) {
  const container = document.querySelector("#global-chat-messages");
  const key = JSON.stringify(messages);
  if (globalChatKey === key) return;
  globalChatKey = key;
  const wasNearBottom =
    container.scrollHeight - container.scrollTop - container.clientHeight < 64;
  const latestMessageId = messages.at(-1)?.id ?? null;
  const hasNewMessages = globalChatInitialized && latestMessageId !== globalChatLastMessageId;
  globalChatLastMessageId = latestMessageId;
  globalChatInitialized = true;
  document.querySelector("#global-chat-count").textContent =
    `${messages.length} ${messages.length === 1 ? "message" : "messages"}`;
  container.replaceChildren();
  if (!messages.length) {
    const empty = document.createElement("p");
    empty.className = "muted";
    empty.textContent = "No messages yet. Start the conversation.";
    container.append(empty);
    document.querySelector("#global-chat-latest").classList.add("hidden");
    return;
  }
  for (const chatMessage of messages) {
    const entry = document.createElement("article");
    entry.className = `global-chat-entry${chatMessage.own ? " own" : ""}`;
    const avatar = document.createElement("span");
    avatar.className = "global-chat-avatar";
    avatar.textContent = chatMessage.username.slice(0, 1).toUpperCase();
    avatar.setAttribute("aria-hidden", "true");
    const copy = document.createElement("div");
    copy.className = "global-chat-copy";
    const heading = document.createElement("div");
    heading.className = "global-chat-message-heading";
    const author = document.createElement("strong");
    author.textContent = chatMessage.own ? "You" : chatMessage.username;
    const sentAt = document.createElement("time");
    sentAt.dateTime = new Date(chatMessage.createdAt).toISOString();
    sentAt.textContent = new Date(chatMessage.createdAt).toLocaleTimeString([], {
      hour: "numeric",
      minute: "2-digit",
    });
    heading.append(author, sentAt);
    const body = document.createElement("p");
    body.className = "global-chat-bubble";
    body.textContent = chatMessage.message;
    copy.append(heading, body);
    entry.append(avatar, copy);

    if (!chatMessage.own && signedInUser) {
      const actions = document.createElement("div");
      actions.className = "global-chat-actions";
      if (chatMessage.isFriend) {
        actions.append(globalChatAction("Invite to game", async () => {
          try {
            const timeControl = await openInviteTimePicker(chatMessage.username);
            if (!timeControl) return;
            await api("/api/invitations", {
              method: "POST",
              body: JSON.stringify({ friendId: chatMessage.userId, timeControl }),
            });
            globalChatStatus(`Game invitation sent to ${chatMessage.username}.`);
          } catch (error) {
            globalChatStatus(error.message);
          }
        }, false, true));
      } else if (chatMessage.receivedRequestId) {
        actions.append(globalChatAction("Accept request", async () => {
          try {
            await api(`/api/friends/requests/${chatMessage.receivedRequestId}`, {
              method: "POST",
              body: JSON.stringify({ accept: true }),
            });
            globalChatStatus(`You and ${chatMessage.username} are now friends.`);
            await Promise.all([loadDashboard(), loadGlobalChat()]);
          } catch (error) {
            globalChatStatus(error.message);
          }
        }, false, true));
      } else if (chatMessage.sentRequestId) {
        actions.append(globalChatAction("Request sent", () => {}, true));
      } else {
        actions.append(globalChatAction("Add friend", async () => {
          try {
            const result = await api("/api/friends/requests", {
              method: "POST",
              body: JSON.stringify({ username: chatMessage.username }),
            });
            globalChatStatus(result.status === "friends"
              ? `You and ${chatMessage.username} are now friends.`
              : `Friend request sent to ${chatMessage.username}.`);
            await Promise.all([loadDashboard(), loadGlobalChat()]);
          } catch (error) {
            globalChatStatus(error.message);
          }
        }));
      }
      entry.append(actions);
    }
    container.append(entry);
  }
  const jumpButton = document.querySelector("#global-chat-latest");
  if (wasNearBottom) {
    container.scrollTop = container.scrollHeight;
    jumpButton.classList.add("hidden");
  } else if (hasNewMessages) {
    jumpButton.classList.remove("hidden");
  }
}

async function loadGlobalChat() {
  try {
    const { messages } = await api("/api/global-chat");
    renderGlobalChat(messages);
  } catch (error) {
    const container = document.querySelector("#global-chat-messages");
    globalChatKey = "";
    container.replaceChildren();
    const status = document.createElement("p");
    status.className = "muted";
    status.textContent = error.message;
    container.append(status);
  }
}

function setAccountView(user) {
  signedInUser = user;
  friendIds = new Set();
  sentFriendIds = new Set();
  incomingFriendRequests = new Map();
  shopState = null;
  const signedIn = Boolean(user);
  accountPanel.classList.toggle("hidden", signedIn);
  friendsPanel.classList.toggle("hidden", !signedIn);
  document.querySelector("#logout-button").classList.toggle("hidden", !signedIn);
  document.querySelector("#global-chat-form").classList.toggle("hidden", !signedIn);
  document.querySelector("#global-chat-login").classList.toggle("hidden", signedIn);
  document.querySelector(".global-chat-prompts").classList.toggle("hidden", !signedIn);
  void loadGlobalChat();
  if (activeView === "shop") void loadShop();
  if (signedIn) {
    document.querySelector("#welcome-name").textContent = `Hello, ${user.username}`;
    loadDashboard();
    if (dashboardTimer) clearInterval(dashboardTimer);
    dashboardTimer = setInterval(loadDashboard, 5000);
  } else if (dashboardTimer) {
    clearInterval(dashboardTimer);
    dashboardTimer = null;
  }
  if (!signedIn) void loadLeaderboard();
}

function setLobbyView(view) {
  activeView = view;
  document.querySelector("#home-content").classList.toggle("hidden", view !== "home");
  document.querySelector("#global-chat-panel").classList.toggle("hidden", view !== "chat");
  document.querySelector("#shop-panel").classList.toggle("hidden", view !== "shop");
  const chatToggle = document.querySelector("#global-chat-toggle");
  chatToggle.textContent = view === "chat" ? "Home" : "Global chat";
  chatToggle.setAttribute("aria-pressed", String(view === "chat"));
  const shopToggle = document.querySelector("#shop-toggle");
  shopToggle.textContent = view === "shop" ? "Home" : "Shop";
  shopToggle.setAttribute("aria-pressed", String(view === "shop"));
  if (globalChatTimer) {
    clearInterval(globalChatTimer);
    globalChatTimer = null;
  }
  if (view === "chat") {
    void loadGlobalChat();
    globalChatTimer = window.setInterval(loadGlobalChat, 3000);
    document.querySelector("#global-chat-input").focus();
  } else if (view === "shop") {
    void loadShop();
  }
}

function renderSkinCards(type, container, skins = shopState.skins[type]) {
  container.replaceChildren();
  for (const skin of skins) {
    const card = document.createElement("article");
    card.className = `skin-card${skin.equipped ? " equipped" : ""}`;
    const preview = document.createElement("div");
    if (type === "board") {
      preview.className = `skin-preview board-preview board-preview-${skin.id}`;
      preview.setAttribute("aria-hidden", "true");
    } else {
      preview.className = `skin-preview piece-preview piece-preview-${skin.id}`;
      preview.setAttribute("aria-hidden", "true");
      for (const [className, symbol, pieceCode] of [
        ["demo-white", "♔", "wk"], ["demo-black", "♚", "bk"],
        ["demo-white", "♘", "wn"], ["demo-black", "♞", "bn"],
      ]) {
        const piece = document.createElement("span");
        piece.className = `${className} demo-${skin.id}`;
        piece.dataset.piece = pieceCode;
        piece.textContent = symbol;
        preview.append(piece);
      }
    }
    const copy = document.createElement("div");
    copy.className = "skin-card-copy";
    const name = document.createElement("strong");
    name.textContent = skin.name;
    const price = document.createElement("span");
    price.textContent = skin.ownerOnly
      ? skin.owned ? "Owner exclusive" : ""
      : skin.price ? `${skin.price} coins` : "Included";
    price.hidden = Boolean(skin.ownerOnly && !skin.owned);
    copy.append(name, price);
    if (type === "board" && skin.id === "nebula") {
      const note = document.createElement("span");
      note.className = "skin-card-note";
      note.setAttribute("role", "note");
      note.textContent = "A unique constellation is drawn across your half each game.";
      copy.append(note);
    }
    const locked = Boolean(skin.ownerOnly && !skin.owned);
    const actionLabel = skin.equipped
      ? "Equipped"
      : locked ? "Owner only"
        : skin.owned ? "Equip" : `Buy · ${skin.price} coins`;
    const action = button(
      actionLabel,
      async () => {
        action.disabled = true;
        try {
          const endpoint = skin.ownerOnly || skin.owned ? "equip" : "purchase";
          shopState = await api(`/api/shop/${endpoint}`, {
            method: "POST",
            body: JSON.stringify({ type, skinId: skin.id }),
          });
          renderShop();
          shopStatus(`${skin.owned ? "Equipped" : "Purchased"} ${skin.name}.`);
        } catch (error) {
          action.disabled = false;
          shopStatus(error.message);
        }
      },
      skin.equipped,
    );
    action.classList.add("skin-card-action");
    action.disabled = skin.equipped || locked;
    const actions = document.createElement("div");
    actions.className = `skin-card-actions${skin.ownerOnly ? " single" : ""}`;
    actions.append(action);
    if (!skin.ownerOnly) {
      const tryButton = button("Try out", async () => {
        tryButton.disabled = true;
        try {
          const game = await api("/api/bot-games", {
            method: "POST",
            body: JSON.stringify({ botElo: 200, skinPreview: true }),
          });
          window.location.href = `${game.url}&try=${encodeURIComponent(`${type}:${skin.id}`)}`;
        } catch (error) {
          tryButton.disabled = false;
          shopStatus(error.message);
        }
      });
      tryButton.classList.add("skin-card-action", "try-skin-button");
      actions.append(tryButton);
    }
    card.append(preview, copy, actions);
    container.append(card);
  }
}

function shopStatus(text) {
  document.querySelector("#shop-status").textContent = text;
}

function renderShop() {
  const signedIn = Boolean(signedInUser && shopState);
  document.querySelector("#shop-login").classList.toggle("hidden", Boolean(signedInUser));
  document.querySelector("#shop-account").classList.toggle("hidden", !signedIn);
  renderSkinCards(
    "piece",
    document.querySelector("#owner-skin-list"),
    shopState?.specialSkins || ownerSkinPreview,
  );
  if (!signedIn) return;
  document.querySelector("#shop-coins").textContent = String(shopState.coins);
  const claimButton = document.querySelector("#claim-daily-coins");
  claimButton.disabled = !shopState.canClaimDaily;
  claimButton.textContent = shopState.canClaimDaily
    ? `Collect ${shopState.dailyReward} daily coins`
    : "Daily coins collected";
  renderSkinCards("board", document.querySelector("#board-skin-list"));
  renderSkinCards("piece", document.querySelector("#piece-skin-list"));
}

async function loadShop() {
  const login = document.querySelector("#shop-login");
  const account = document.querySelector("#shop-account");
  if (!signedInUser) {
    login.classList.remove("hidden");
    account.classList.add("hidden");
    renderShop();
    return;
  }
  try {
    shopState = await api("/api/shop");
    renderShop();
  } catch (error) {
    shopStatus(error.message);
  }
}

function openAcceptedInvitation(games) {
  if (window.location.pathname !== "/") return false;
  const acceptedInvite = games.find((game) =>
    game.is_creator && game.invited_user_id !== null && game.status === "active");
  if (!acceptedInvite) return false;
  const key = `auto-open-invitation:${acceptedInvite.room_code}`;
  if (sessionStorage.getItem(key) === "1") return false;
  sessionStorage.setItem(key, "1");
  window.location.assign(`/play?room=${encodeURIComponent(acceptedInvite.room_code)}`);
  return true;
}

async function loadDashboard() {
  if (!signedInUser) return;
  try {
    const data = await api("/api/dashboard");
    friendIds = new Set(data.friends.map((friend) => Number(friend.id)));
    sentFriendIds = new Set(data.sentRequests.map((request) => Number(request.user_id)));
    incomingFriendRequests = new Map(
      data.requests.map((request) => [Number(request.user_id), request.id]),
    );
    if (openAcceptedInvitation(data.games)) return;
    void loadLeaderboard();
    const friends = document.querySelector("#friend-list");
    friends.replaceChildren();
    if (!data.friends.length) friends.innerHTML = '<p class="muted">No friends yet.</p>';
    for (const friend of data.friends) {
      item(friends, `${friend.username} · ${friend.rating} ELO`, "Invite", async () => {
        try {
          const timeControl = await openInviteTimePicker(friend.username);
          if (!timeControl) return;
          const invite = await api("/api/invitations", {
            method: "POST",
            body: JSON.stringify({
              friendId: friend.id,
              timeControl,
            }),
          });
          tell(`Invitation sent to ${friend.username}.`);
          await copyInvite(invite.roomCode);
          await loadDashboard();
        } catch (error) { tell(error.message); }
      }, true);
    }

    const requests = document.querySelector("#request-list");
    requests.replaceChildren();
    if (!data.requests.length) requests.innerHTML = '<p class="muted">No new requests.</p>';
    for (const request of data.requests) {
      item(requests, request.username, "Accept", async () => {
        try {
          await api(`/api/friends/requests/${request.id}`, {
            method: "POST", body: JSON.stringify({ accept: true }),
          });
          tell(`You and ${request.username} are now friends.`);
          await loadDashboard();
        } catch (error) { tell(error.message); }
      }, true);
      const row = requests.lastElementChild;
      row.append(button("Decline", async () => {
        try {
          await api(`/api/friends/requests/${request.id}`, {
            method: "POST", body: JSON.stringify({ accept: false }),
          });
          await loadDashboard();
        } catch (error) { tell(error.message); }
      }));
    }

    const invitations = document.querySelector("#invitation-list");
    invitations.replaceChildren();
    if (!data.invitations.length) invitations.innerHTML = '<p class="muted">No invitations waiting.</p>';
    queueInvitationPrompts(data.invitations);
    for (const invite of data.invitations) {
      item(invitations, `${invite.inviter} is ready to play`, "Join game", async () => {
        try {
          await joinInvitation(invite);
        } catch (error) { tell(error.message); }
      }, true);
    }

    const games = document.querySelector("#game-list");
    games.replaceChildren();
    if (!data.games.length) games.innerHTML = '<p class="muted">No active games.</p>';
    const presentInvite = data.games.find(
      (game) => game.is_creator && game.status === "waiting" &&
        game.invited_user_id !== null && game.opponent_present,
    );
    const opponentNotification = document.querySelector("#opponent-notification");
    opponentNotification.classList.toggle("hidden", !presentInvite);
    if (presentInvite) {
      document.querySelector("#opponent-notification-text").textContent =
        "Your opponent is here and ready to join.";
      document.querySelector("#opponent-notification-join").href =
        `/play?room=${encodeURIComponent(presentInvite.room_code)}`;
    }
    for (const game of data.games) {
      const white = game.white_name || "Guest";
      const black = game.black_name ||
        (game.status === "waiting" ? "Waiting for player" : "Guest");
      const row = document.createElement("div");
      row.className = "game-list-item";
      const details = document.createElement("div");
      details.className = "game-list-details";
      const players = document.createElement("strong");
      players.textContent = `${white} vs ${black}`;
      const status = document.createElement("span");
      status.textContent = game.status === "waiting"
        ? game.opponent_present
          ? "Your opponent is here. Join the room when you’re ready."
          : "Your room is ready when your opponent joins."
        : "Your match is in progress. Pick up where you left off.";
      details.append(players, status);
      const continueButton = button(
        game.status === "waiting" ? "View room" : "Rejoin game",
        () => {
          window.location.href = `/play?room=${encodeURIComponent(game.room_code)}`;
        },
        true,
      );
      const closeButton = button("Close room", async () => {
        const confirmation = game.status === "active"
          ? "Close this active game? This will forfeit the match and may change both players’ ratings."
          : "Close this waiting room? Your opponent will no longer be able to join.";
        if (!window.confirm(confirmation)) return;
        closeButton.disabled = true;
        try {
          await api(`/api/rooms/${encodeURIComponent(game.room_code)}/close`, {
            method: "POST",
            body: "{}",
          });
          tell(game.status === "active"
            ? "Game closed and recorded as a forfeit."
            : "Waiting room closed.");
          await loadDashboard();
        } catch (error) {
          tell(error.message);
          closeButton.disabled = false;
        }
      });
      closeButton.classList.add("danger");
      row.append(details, continueButton, closeButton);
      games.append(row);
    }
  } catch (error) {
    tell(error.message);
  }
}

async function copyInvite(roomCode) {
  inviteUrl = new URL(`/play?room=${encodeURIComponent(roomCode)}`, window.location.origin).href;
  const invitePanel = document.querySelector("#invite-share");
  const inviteInput = document.querySelector("#invite-url");
  inviteInput.value = inviteUrl;
  invitePanel.classList.remove("hidden");
  try {
    await navigator.clipboard.writeText(inviteUrl);
    tell("Invite link copied. Paste it anywhere to invite your opponent.");
  } catch {
    tell("Select the invite link below and copy it to share with your opponent.");
    inviteInput.focus();
    inviteInput.select();
  }
}

document.querySelector("#copy-invite").addEventListener("click", async () => {
  if (!inviteUrl) return;
  try {
    await navigator.clipboard.writeText(inviteUrl);
    tell("Invite link copied.");
  } catch {
    const input = document.querySelector("#invite-url");
    input.focus();
    input.select();
    tell("The link is selected. Copy it to share with your opponent.");
  }
});

document.querySelector("#account-switch").addEventListener("click", () => {
  isRegistering = !isRegistering;
  document.querySelector("#account-heading").textContent = isRegistering ? "Create your account" : "Welcome back";
  document.querySelector("#account-submit").textContent = isRegistering ? "Create account" : "Sign in";
  document.querySelector("#account-switch").textContent = isRegistering ? "Already have an account? Sign in" : "Create an account";
  document.querySelector("#password-input").autocomplete = isRegistering ? "new-password" : "current-password";
});

accountForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const buttonElement = document.querySelector("#account-submit");
  buttonElement.disabled = true;
  try {
    const path = isRegistering ? "/api/register" : "/api/login";
    const result = await api(path, {
      method: "POST",
      body: JSON.stringify({
        username: document.querySelector("#username-input").value.trim(),
        password: document.querySelector("#password-input").value,
      }),
    });
    document.querySelector("#password-input").value = "";
    setAccountView(result.user);
    tell(`Signed in as ${result.user.username}.`);
  } catch (error) {
    tell(error.message);
  } finally {
    buttonElement.disabled = false;
  }
});

document.querySelector("#logout-button").addEventListener("click", async () => {
  try {
    await api("/api/logout", { method: "POST", body: "{}" });
    setAccountView(null);
    tell("You have signed out.");
  } catch (error) { tell(error.message); }
});

document.querySelector("#play-bot").addEventListener("click", async (event) => {
  const playButton = event.currentTarget;
  playButton.disabled = true;
  try {
    const game = await api("/api/bot-games", {
      method: "POST",
      body: JSON.stringify({
        botElo: Number(document.querySelector('input[name="bot-opponent"]:checked').value),
        timeControl: document.querySelector("#time-control").value,
      }),
    });
    window.location.href = `/play?room=${encodeURIComponent(game.roomCode)}`;
  } catch (error) {
    tell(error.message);
    playButton.disabled = false;
  }
});

function closeProfile() {
  document.querySelector("#profile-modal").classList.add("hidden");
}

document.querySelector("#close-profile").addEventListener("click", closeProfile);
document.querySelector("#profile-modal").addEventListener("click", (event) => {
  if (event.target.id === "profile-modal") closeProfile();
});
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") closeProfile();
});

document.querySelector("#create-room").addEventListener("click", async () => {
  try {
    const room = await api("/api/rooms", {
      method: "POST",
      body: JSON.stringify({ timeControl: document.querySelector("#time-control").value }),
    });
    await copyInvite(room.roomCode);
    window.location.href = room.url;
  } catch (error) { tell(error.message); }
});

document.querySelector("#join-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const code = document.querySelector("#room-code").value.trim().toUpperCase();
  try {
    await api(`/api/rooms/${encodeURIComponent(code)}/join`, { method: "POST", body: "{}" });
    window.location.href = `/play?room=${encodeURIComponent(code)}`;
  } catch (error) { tell(error.message); }
});

document.querySelector("#friend-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    const result = await api("/api/friends/requests", {
      method: "POST",
      body: JSON.stringify({ username: document.querySelector("#friend-username").value.trim() }),
    });
    document.querySelector("#friend-username").value = "";
    tell(result.status === "friends" ? "Friend request accepted." : "Friend request sent.");
    await loadDashboard();
  } catch (error) { tell(error.message); }
});

document.querySelector("#invite-time-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const selected = document.querySelector('input[name="invite-time-control"]:checked');
  if (!selected) {
    tell("Choose a time control before sending the invitation.");
    return;
  }
  closeInviteTimePicker(selected.value);
});
document.querySelector("#cancel-invite-time").addEventListener("click", () => {
  closeInviteTimePicker();
});
document.querySelector("#close-invite-time").addEventListener("click", () => {
  closeInviteTimePicker();
});
document.querySelector("#invite-time-modal").addEventListener("click", (event) => {
  if (event.target.id === "invite-time-modal") closeInviteTimePicker();
});
document.querySelector("#global-chat-toggle").addEventListener("click", () => {
  setLobbyView(activeView === "chat" ? "home" : "chat");
});
document.querySelector("#shop-toggle").addEventListener("click", () => {
  setLobbyView(activeView === "shop" ? "home" : "shop");
});
if (new URLSearchParams(window.location.search).get("view") === "shop") {
  setLobbyView("shop");
}
document.querySelector("#shop-sign-in").addEventListener("click", () => {
  setLobbyView("home");
  document.querySelector("#username-input").focus();
});
document.querySelector("#claim-daily-coins").addEventListener("click", async (event) => {
  const claimButton = event.currentTarget;
  claimButton.disabled = true;
  try {
    shopState = await api("/api/shop/daily", { method: "POST", body: "{}" });
    renderShop();
    shopStatus(`${shopState.dailyReward} coins added to your balance.`);
  } catch (error) {
    shopStatus(error.message);
    claimButton.disabled = false;
  }
});
document.querySelector("#global-chat-sign-in").addEventListener("click", () => {
  document.querySelector("#global-chat-toggle").click();
  document.querySelector("#username-input").focus();
});
document.querySelector("#global-chat-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const sendButton = document.querySelector("#global-chat-send");
  const input = document.querySelector("#global-chat-input");
  sendButton.disabled = true;
  try {
    await api("/api/global-chat", {
      method: "POST",
      body: JSON.stringify({ message: input.value }),
    });
    input.value = "";
    updateGlobalChatCharacterCount();
    globalChatStatus("Message sent.");
    await loadGlobalChat();
  } catch (error) {
    globalChatStatus(error.message);
  } finally {
    sendButton.disabled = false;
  }
});
const globalChatMessages = document.querySelector("#global-chat-messages");
globalChatMessages.addEventListener("scroll", () => {
  if (globalChatMessages.scrollHeight - globalChatMessages.scrollTop -
      globalChatMessages.clientHeight < 64) {
    document.querySelector("#global-chat-latest").classList.add("hidden");
  }
});
document.querySelector("#global-chat-latest").addEventListener("click", () => {
  globalChatMessages.scrollTo({ top: globalChatMessages.scrollHeight, behavior: "smooth" });
});
document.querySelector("#global-chat-refresh").addEventListener("click", () => {
  void loadGlobalChat();
});
document.querySelector("#global-chat-input").addEventListener(
  "input",
  updateGlobalChatCharacterCount,
);
for (const prompt of document.querySelectorAll(".global-chat-prompt")) {
  prompt.addEventListener("click", () => {
    const input = document.querySelector("#global-chat-input");
    input.value = prompt.dataset.chatPrompt || "";
    updateGlobalChatCharacterCount();
    input.focus();
  });
}
for (const [tabId, panelId, otherTabId, otherPanelId] of [
  ["leaderboard-tab", "leaderboard-panel", "live-matches-tab", "live-matches-panel"],
  ["live-matches-tab", "live-matches-panel", "leaderboard-tab", "leaderboard-panel"],
]) {
  document.querySelector(`#${tabId}`).addEventListener("click", () => {
    document.querySelector(`#${tabId}`).classList.add("selected");
    document.querySelector(`#${tabId}`).setAttribute("aria-selected", "true");
    document.querySelector(`#${otherTabId}`).classList.remove("selected");
    document.querySelector(`#${otherTabId}`).setAttribute("aria-selected", "false");
    document.querySelector(`#${panelId}`).classList.remove("hidden");
    document.querySelector(`#${otherPanelId}`).classList.add("hidden");
    if (tabId === "live-matches-tab") void loadLiveMatches();
  });
}
document.querySelector("#join-prompt-join").addEventListener("click", async () => {
  if (!activeInvitationPrompt) return;
  const invite = activeInvitationPrompt;
  try {
    await joinInvitation(invite);
  } catch (error) {
    tell(error.message);
    document.querySelector("#join-prompt-modal").classList.add("hidden");
    activeInvitationPrompt = null;
    showNextInvitationPrompt();
  }
});
document.querySelector("#join-prompt-later").addEventListener("click", () => {
  document.querySelector("#join-prompt-modal").classList.add("hidden");
  activeInvitationPrompt = null;
  showNextInvitationPrompt();
});
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" &&
      !document.querySelector("#invite-time-modal").classList.contains("hidden")) {
    closeInviteTimePicker();
  }
  if (event.key === "Escape" &&
      !document.querySelector("#join-prompt-modal").classList.contains("hidden")) {
    document.querySelector("#join-prompt-later").click();
  }
});

api("/api/session")
  .then(({ user }) => setAccountView(user))
  .catch((error) => tell(error.message));
void loadLiveMatches();
window.setInterval(loadLiveMatches, 5000);
